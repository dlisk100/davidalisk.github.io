/* Nationwide source-backed display corridors; physical geometry never supplies freight widths. */
'use strict';
const RoadCorridors=(()=>{
 const cache=new Map(),pending=new Map();let generation=0;
 function name(key){if(key.startsWith('truck|local|')){const p=key.split('|');return p[3]+' · '+p[2];}return key.startsWith('truck|')?key.slice(6).replaceAll('|',' · '):'Road stretch';}
 function sourceNote(r){return{id:r[0],sourceIndex:r[1],sign:r[3],localName:r[4],state:r[5],roadClass:r[6],modeledSourceIDs:r[7],flow:r[7].length?'retained modeled source':'unknown modeled flow'};}
 async function load(key,read){
  if(cache.has(key))return cache.get(key);
  if(pending.has(key))return pending.get(key);
  const file=globalThis.ROAD_CORRIDORS?.index?.[key];if(!file)return null;
  const gen=generation;
  const job=Promise.resolve().then(()=>read('road-corridors/'+file)).then(data=>{
   if(gen!==generation)throw Error('Physical road runtime disposed');
   if(data.schema!=='source-backed-road-corridor-v1'||data.key!==key)throw Error('Invalid physical corridor '+key);
   cache.set(key,data);while(cache.size>2)cache.delete(cache.keys().next().value);return data;
  }).finally(()=>{if(pending.get(key)===job)pending.delete(key);});pending.set(key,job);return job;
 }
 function visible(ll,proj,view){const pts=ll.map(proj).filter(Boolean);if(pts.length<2)return null;
  if(view){let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;for(const q of pts){x0=Math.min(x0,q[0]);y0=Math.min(y0,q[1]);x1=Math.max(x1,q[0]);y1=Math.max(y1,q[1]);}if(x1<view[0]||x0>view[2]||y1<view[1]||y0>view[3])return null;}return pts;}
 function paint(ctx,data,proj,k,view){if(!data)return;ctx.save();ctx.globalAlpha=1;ctx.strokeStyle='#81776b';ctx.lineWidth=1.4/k;ctx.lineCap='round';ctx.lineJoin='round';ctx.setLineDash([]);ctx.beginPath();let n=0;
  // One solid neutral physical backbone, not a freight ribbon or renamed detour.
  for(const r of data.rows){const pts=visible(r[2],proj,view);if(!pts)continue;pts.forEach((q,j)=>j?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));n++;}
  if(n)ctx.stroke();ctx.restore();}
 function pick(data,proj,p,k){if(!data)return null;let best=null,dmin=4/k;
  for(const r of data.rows){const pts=visible(r[2],proj,[p[0]-dmin,p[1]-dmin,p[0]+dmin,p[1]+dmin]);if(!pts)continue;for(let j=1;j<pts.length;j++){const a=pts[j-1],b=pts[j],dx=b[0]-a[0],dy=b[1]-a[1],l=dx*dx+dy*dy,u=Math.max(0,Math.min(1,l?((p[0]-a[0])*dx+(p[1]-a[1])*dy)/l:0)),d=Math.hypot(p[0]-a[0]-u*dx,p[1]-a[1]-u*dy);if(d<dmin){dmin=d;best=r;}}}return best;}
 function dispose(){generation++;cache.clear();pending.clear();}
 function labelChain(r,key,keyOf){let best=[],length=0;for(const chain of r.chains){let run=[],sum=0;const flush=()=>{if(sum>length){best=run;length=sum;}run=[];sum=0;};for(const x of chain){if(keyOf(x.s)===key){run.push(x);sum+=x.s.len;}else flush();}flush();}return best;}
 return{name,sourceNote,load,paint,pick,dispose,labelChain};
})();
if(typeof module!=='undefined')module.exports=RoadCorridors;
